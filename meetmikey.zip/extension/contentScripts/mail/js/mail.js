(function() {

  MeetMikey.Helper.Setup.start();

}).call(this);
