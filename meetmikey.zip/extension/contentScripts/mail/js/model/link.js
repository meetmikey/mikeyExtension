(function() {
  var __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  MeetMikey.Model.Link = (function(_super) {

    __extends(Link, _super);

    function Link() {
      return Link.__super__.constructor.apply(this, arguments);
    }

    Link.prototype.idAttribute = "_id";

    Link.prototype.decorator = MeetMikey.Decorator.Link;

    return Link;

  })(MeetMikey.Model.Base);

}).call(this);
