(function() {
  var _this = this,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  MeetMikey.Model.Base = (function(_super) {

    __extends(Base, _super);

    function Base() {
      var _this = this;
      this.decorate = function() {
        return Base.prototype.decorate.apply(_this, arguments);
      };
      return Base.__super__.constructor.apply(this, arguments);
    }

    Base.prototype.decorate = function() {
      return this.decorator.decorate(this);
    };

    return Base;

  })(Backbone.Model);

}).call(this);
