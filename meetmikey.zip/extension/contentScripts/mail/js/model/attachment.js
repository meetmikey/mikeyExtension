(function() {
  var _this = this,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  MeetMikey.Model.Attachment = (function(_super) {

    __extends(Attachment, _super);

    function Attachment() {
      var _this = this;
      this.isImage = function() {
        return Attachment.prototype.isImage.apply(_this, arguments);
      };
      return Attachment.__super__.constructor.apply(this, arguments);
    }

    Attachment.prototype.idAttribute = "_id";

    Attachment.prototype.decorator = MeetMikey.Decorator.Attachment;

    Attachment.prototype.isImage = function() {
      return /^image\/.+/.test(this.get('contentType'));
    };

    return Attachment;

  })(MeetMikey.Model.Base);

}).call(this);
