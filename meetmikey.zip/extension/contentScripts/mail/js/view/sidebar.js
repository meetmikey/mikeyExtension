(function() {
  var _this = this,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  MeetMikey.View.Sidebar = (function(_super) {

    __extends(Sidebar, _super);

    function Sidebar() {
      var _this = this;
      this.postInitialize = function() {
        return Sidebar.prototype.postInitialize.apply(_this, arguments);
      };
      this.showInbox = function() {
        return Sidebar.prototype.showInbox.apply(_this, arguments);
      };
      return Sidebar.__super__.constructor.apply(this, arguments);
    }

    Sidebar.prototype.renderSelf = false;

    Sidebar.prototype.events = {
      'click .aim': 'showInbox'
    };

    Sidebar.prototype.showInbox = function() {
      this.trigger('clicked:inbox');
      return console.log('inbox triggered');
    };

    Sidebar.prototype.postInitialize = function() {};

    return Sidebar;

  })(MeetMikey.View.Base);

}).call(this);
