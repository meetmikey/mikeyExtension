(function() {
  var template,
    _this = this,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  template = "<a href=\"#\" class=\"prev-page\">Prev</a>\n<span class=\"page-count\">Page {{page}}</span>\n<a href=\"#\" class=\"next-page\">Next</a>";

  MeetMikey.View.Pagination = (function(_super) {

    __extends(Pagination, _super);

    function Pagination() {
      var _this = this;
      this.prevPage = function(event) {
        return Pagination.prototype.prevPage.apply(_this, arguments);
      };
      this.pageFetched = function(collection, response) {
        return Pagination.prototype.pageFetched.apply(_this, arguments);
      };
      this.fetchNextPage = function(callback) {
        return Pagination.prototype.fetchNextPage.apply(_this, arguments);
      };
      this.nextPage = function(event) {
        return Pagination.prototype.nextPage.apply(_this, arguments);
      };
      this.getPageItems = function() {
        return Pagination.prototype.getPageItems.apply(_this, arguments);
      };
      this.getTemplateData = function() {
        return Pagination.prototype.getTemplateData.apply(_this, arguments);
      };
      return Pagination.__super__.constructor.apply(this, arguments);
    }

    Pagination.prototype.template = Handlebars.compile(template);

    Pagination.prototype.events = {
      'click .next-page': 'nextPage',
      'click .prev-page': 'prevPage'
    };

    Pagination.prototype.page = 0;

    Pagination.prototype.itemsPerPage = 50;

    Pagination.prototype.getTemplateData = function() {
      return {
        page: this.page + 1
      };
    };

    Pagination.prototype.getPageItems = function() {
      return _.chain(this.collection.models).rest(this.page * this.itemsPerPage).first(this.itemsPerPage).value();
    };

    Pagination.prototype.nextPage = function(event) {
      event.preventDefault();
      if ((this.lastPage != null) && this.page + 1 > this.lastPage) {
        return;
      }
      this.page += 1;
      if (this.page * this.itemsPerPage + 1 > this.collection.length) {
        return this.fetchNextPage();
      } else {
        return this.trigger('changed:page');
      }
    };

    Pagination.prototype.fetchNextPage = function(callback) {
      var _ref;
      return this.collection.fetch({
        silent: true,
        update: true,
        remove: false,
        data: {
          before: (_ref = this.collection.last()) != null ? _ref.get('sentDate') : void 0,
          limit: this.itemsPerPage
        },
        success: this.pageFetched
      });
    };

    Pagination.prototype.pageFetched = function(collection, response) {
      if (response.length < this.itemsPerPage) {
        this.lastPage = this.page;
      }
      return this.trigger('changed:page');
    };

    Pagination.prototype.prevPage = function(event) {
      event.preventDefault();
      if (!(this.page > 0)) {
        return;
      }
      this.page -= 1;
      return this.trigger('changed:page');
    };

    return Pagination;

  })(MeetMikey.View.Base);

}).call(this);
