(function() {
  var _this = this,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  MeetMikey.View.Rollover = (function(_super) {

    __extends(Rollover, _super);

    function Rollover() {
      var _this = this;
      this.setQuery = function(query) {
        return Rollover.prototype.setQuery.apply(_this, arguments);
      };
      this.cancelHide = function() {
        return Rollover.prototype.cancelHide.apply(_this, arguments);
      };
      this.hide = function() {
        return Rollover.prototype.hide.apply(_this, arguments);
      };
      this.startHide = function() {
        return Rollover.prototype.startHide.apply(_this, arguments);
      };
      this.cancelSpawn = function() {
        return Rollover.prototype.cancelSpawn.apply(_this, arguments);
      };
      this.spawn = function(cid) {
        return Rollover.prototype.spawn.apply(_this, arguments);
      };
      this.delaySpawn = function(event) {
        return Rollover.prototype.delaySpawn.apply(_this, arguments);
      };
      this.startSpawn = function(event) {
        return Rollover.prototype.startSpawn.apply(_this, arguments);
      };
      this.postRender = function() {
        return Rollover.prototype.postRender.apply(_this, arguments);
      };
      this.postInitialize = function() {
        return Rollover.prototype.postInitialize.apply(_this, arguments);
      };
      this.getTemplateData = function() {
        return Rollover.prototype.getTemplateData.apply(_this, arguments);
      };
      return Rollover.__super__.constructor.apply(this, arguments);
    }

    Rollover.prototype.hideFlag = false;

    Rollover.prototype.events = {
      'mouseleave': 'startHide',
      'mouseenter': 'cancelHide'
    };

    Rollover.prototype.getTemplateData = function() {
      return _.extend(this.model.decorate(), {
        searchQuery: this.searchQuery
      });
    };

    Rollover.prototype.postInitialize = function() {
      return this.cursorInfo = {};
    };

    Rollover.prototype.postRender = function() {
      $(document).one('mousemove', this.startHide);
      return this.$('.rollover-box').css({
        left: this.cursorInfo.x + 5,
        top: this.cursorInfo.y
      });
    };

    Rollover.prototype.startSpawn = function(event) {
      var cid;
      cid = $(event.target).closest('tr').attr('data-cid');
      this.cursorInfo.cid = cid;
      this.cursorInfo.x = event.clientX;
      this.cursorInfo.y = event.clientY;
      return this.waitAndSpawn(cid);
    };

    Rollover.prototype.delaySpawn = function(event) {
      var cid;
      cid = $(event.target).closest('tr').attr('data-cid');
      this.cursorInfo.x = event.clientX;
      this.cursorInfo.y = event.clientY;
      return this.waitAndSpawn(cid);
    };

    Rollover.prototype.spawn = function(cid) {
      if (cid !== this.cursorInfo.cid) {
        return;
      }
      this.model = this.collection.get(cid);
      this.render();
      return this.$el.show();
    };

    Rollover.prototype.waitAndSpawn = _.debounce(Rollover.prototype.spawn, 400);

    Rollover.prototype.cancelSpawn = function() {
      return this.cursorInfo.cid = null;
    };

    Rollover.prototype.startHide = function() {
      this.hideFlag = true;
      return this.waitAndHide();
    };

    Rollover.prototype.hide = function() {
      if (this.hideFlag) {
        return this.$el.hide();
      }
    };

    Rollover.prototype.waitAndHide = _.debounce(Rollover.prototype.hide, 400);

    Rollover.prototype.cancelHide = function() {
      return this.hideFlag = false;
    };

    Rollover.prototype.setQuery = function(query) {
      return this.searchQuery = query;
    };

    return Rollover;

  })(MeetMikey.View.Base);

}).call(this);
