(function() {
  var downloadUrl, template,
    _this = this,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  template = "{{#unless models}}\n  <div class=\"mm-placeholder\">Oops. It doesn't look like Mikey has any files for you.</div>\n{{else}}\n  <div class=\"pagination-container\"></div>\n  <table class=\"inbox-table\" id=\"mm-attachments-table\" border=\"0\">\n    <thead class=\"labels\">\n      <!-- <th class=\"mm-toggle-box\"></th> -->\n\n      <th class=\"mm-download\">File</th>\n      <th class=\"mm-icon\">&nbsp;</th>\n      <th class=\"mm-file\">&nbsp;</th>\n      <th class=\"mm-from\">From</th>\n      <th class=\"mm-to\">To</th>\n      <th class=\"mm-type\">Type</th>\n      <th class=\"mm-size\">Size</th>\n      <th class=\"mm-sent\">Sent</th>\n    </thead>\n    <tbody>\n  {{#each models}}\n    <tr class=\"files\" data-cid=\"{{cid}}\">\n      <!-- <td class=\"mm-toggle-box\">\n        <div class=\"checkbox\"><div class=\"check\"></div></div>\n      </td> -->\n\n      <td class=\"mm-download\" style=\"background-image: url('{{../downloadUrl}}');\">&nbsp;</td>\n      <td class=\"mm-icon\" style=\"background:url('{{iconUrl}}') no-repeat;\">&nbsp;</td>\n      <td class=\"mm-file truncate\">{{filename}}&nbsp;</td>\n      <td class=\"mm-from truncate\">{{from}}</td>\n      <td class=\"mm-to truncate\">{{to}}</td>\n      <td class=\"mm-type truncate\">{{type}}</td>\n      <td class=\"mm-size truncate\">{{size}}</td>\n      <td class=\"mm-sent truncate\">{{sentDate}}</td>\n    </tr>\n  {{/each}}\n  </tbody>\n  </table>\n  <div class=\"rollover-container\"></div>\n{{/unless}}";

  downloadUrl = chrome.extension.getURL("" + MeetMikey.Settings.imgPath + "/download.png");

  MeetMikey.View.Attachments = (function(_super) {

    __extends(Attachments, _super);

    function Attachments() {
      var _this = this;
      this.poll = function() {
        return Attachments.prototype.poll.apply(_this, arguments);
      };
      this.waitAndPoll = function() {
        return Attachments.prototype.waitAndPoll.apply(_this, arguments);
      };
      this.setResults = function(models, query) {
        return Attachments.prototype.setResults.apply(_this, arguments);
      };
      this.cancelRollover = function() {
        return Attachments.prototype.cancelRollover.apply(_this, arguments);
      };
      this.delayRollover = function(event) {
        return Attachments.prototype.delayRollover.apply(_this, arguments);
      };
      this.startRollover = function(event) {
        return Attachments.prototype.startRollover.apply(_this, arguments);
      };
      this.openMessage = function(event) {
        return Attachments.prototype.openMessage.apply(_this, arguments);
      };
      this.openAttachment = function(event) {
        return Attachments.prototype.openAttachment.apply(_this, arguments);
      };
      this.getModels = function() {
        return Attachments.prototype.getModels.apply(_this, arguments);
      };
      this.getTemplateData = function() {
        return Attachments.prototype.getTemplateData.apply(_this, arguments);
      };
      this.teardown = function() {
        return Attachments.prototype.teardown.apply(_this, arguments);
      };
      this.postRender = function() {
        return Attachments.prototype.postRender.apply(_this, arguments);
      };
      this.postInitialize = function() {
        return Attachments.prototype.postInitialize.apply(_this, arguments);
      };
      this.preInitialize = function() {
        return Attachments.prototype.preInitialize.apply(_this, arguments);
      };
      return Attachments.__super__.constructor.apply(this, arguments);
    }

    Attachments.prototype.template = Handlebars.compile(template);

    Attachments.prototype.subViews = {
      'pagination': {
        viewClass: MeetMikey.View.Pagination,
        selector: '.pagination-container'
      }
    };

    Attachments.prototype.events = {
      'click .files .mm-file': 'openMessage',
      'click .files .mm-download': 'openAttachment',
      'mouseenter .files .mm-file, .files .mm-icon': 'startRollover',
      'mouseleave .files .mm-file, .files .mm-icon': 'cancelRollover',
      'mousemove .files .mm-file, .files .mm-icon': 'delayRollover'
    };

    Attachments.prototype.pollDelay = 1000 * 45;

    Attachments.prototype.preInitialize = function() {};

    Attachments.prototype.postInitialize = function() {
      this.collection = new MeetMikey.Collection.Attachments();
      this.rollover = new MeetMikey.View.AttachmentRollover({
        collection: this.collection,
        search: !this.options.fetch
      });
      this.collection.on('reset add', _.debounce(this.render, 50));
      this.subView('pagination').options.render = this.options.fetch;
      if (this.options.fetch) {
        this.subView('pagination').collection = this.collection;
        this.subView('pagination').on('changed:page', this.render);
        return this.collection.fetch({
          success: this.waitAndPoll
        });
      }
    };

    Attachments.prototype.postRender = function() {
      return this.rollover.setElement(this.$('.rollover-container'));
    };

    Attachments.prototype.teardown = function() {
      return this.collection.off('reset', this.render);
    };

    Attachments.prototype.getTemplateData = function() {
      return {
        models: _.invoke(this.getModels(), 'decorate'),
        downloadUrl: downloadUrl
      };
    };

    Attachments.prototype.getModels = function() {
      if (this.options.fetch) {
        return this.subView('pagination').getPageItems();
      } else {
        return this.collection.models;
      }
    };

    Attachments.prototype.openAttachment = function(event) {
      var cid, model, url;
      cid = $(event.currentTarget).closest('.files').attr('data-cid');
      model = this.collection.get(cid);
      url = MeetMikey.Decorator.Attachment.getUrl(model);
      return window.open(url);
    };

    Attachments.prototype.openMessage = function(event) {
      var cid, hash, model, msgHex;
      cid = $(event.currentTarget).closest('.files').attr('data-cid');
      model = this.collection.get(cid);
      msgHex = model.get('gmMsgHex');
      if (this.options.fetch) {
        hash = "#inbox/" + msgHex;
      } else {
        hash = "#search/" + this.searchQuery + "/" + msgHex;
      }
      return window.location = hash;
    };

    Attachments.prototype.startRollover = function(event) {
      return this.rollover.startSpawn(event);
    };

    Attachments.prototype.delayRollover = function(event) {
      return this.rollover.delaySpawn(event);
    };

    Attachments.prototype.cancelRollover = function() {
      return this.rollover.cancelSpawn();
    };

    Attachments.prototype.setResults = function(models, query) {
      this.searchQuery = query;
      this.rollover.setQuery(query);
      return this.collection.reset(models, {
        sort: false
      });
    };

    Attachments.prototype.waitAndPoll = function() {
      return setTimeout(this.poll, this.pollDelay);
    };

    Attachments.prototype.poll = function() {
      var _ref;
      console.log('attachments are polling');
      return this.collection.fetch({
        update: true,
        remove: false,
        data: {
          after: (_ref = this.collection.first()) != null ? _ref.get('sentDate') : void 0
        },
        success: this.waitAndPoll,
        error: this.waitAndPoll
      });
    };

    return Attachments;

  })(MeetMikey.View.Base);

}).call(this);
