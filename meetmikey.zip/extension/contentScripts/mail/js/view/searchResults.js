(function() {
  var template,
    _this = this,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  template = "<div id=\"mm-search-tabs\"></div>\n<div id=\"mm-search-attachments-tab\" style=\"display: none;\"></div>\n<div id=\"mm-search-links-tab\" style=\"display: none;\"></div>\n<div id=\"mm-search-images-tab\" style=\"display: none;\"></div>";

  MeetMikey.View.SearchResults = (function(_super) {

    __extends(SearchResults, _super);

    function SearchResults() {
      var _this = this;
      this.setResults = function(res) {
        return SearchResults.prototype.setResults.apply(_this, arguments);
      };
      this.teardown = function() {
        return SearchResults.prototype.teardown.apply(_this, arguments);
      };
      this.showTab = function(tab) {
        return SearchResults.prototype.showTab.apply(_this, arguments);
      };
      this.updateCountForTab = function(tab) {
        return SearchResults.prototype.updateCountForTab.apply(_this, arguments);
      };
      this.unbindCountUpdateForTab = function(tab) {
        return SearchResults.prototype.unbindCountUpdateForTab.apply(_this, arguments);
      };
      this.unbindCountUpdate = function() {
        return SearchResults.prototype.unbindCountUpdate.apply(_this, arguments);
      };
      this.bindCountUpdateForTab = function(tab) {
        return SearchResults.prototype.bindCountUpdateForTab.apply(_this, arguments);
      };
      this.bindCountUpdate = function() {
        return SearchResults.prototype.bindCountUpdate.apply(_this, arguments);
      };
      this.postRender = function() {
        return SearchResults.prototype.postRender.apply(_this, arguments);
      };
      this.getTabs = function() {
        return SearchResults.prototype.getTabs.apply(_this, arguments);
      };
      return SearchResults.__super__.constructor.apply(this, arguments);
    }

    SearchResults.prototype.template = Handlebars.compile(template);

    SearchResults.prototype.subViews = {
      'attachments': {
        viewClass: MeetMikey.View.Attachments,
        selector: '#mm-search-attachments-tab'
      },
      'links': {
        viewClass: MeetMikey.View.Links,
        selector: '#mm-search-links-tab'
      },
      'images': {
        viewClass: MeetMikey.View.Images,
        selector: '#mm-search-images-tab'
      }
    };

    SearchResults.prototype.tabs = {
      email: '.UI',
      attachments: '#mm-search-attachments-tab',
      links: '#mm-search-links-tab',
      images: '#mm-search-images-tab'
    };

    SearchResults.prototype.getTabs = function() {
      return _.chain(this.tabs).keys().without('email').value();
    };

    SearchResults.prototype.postRender = function() {};

    SearchResults.prototype.bindCountUpdate = function() {
      var _this = this;
      return _.each(this.getTabs(), function(tab) {
        return _this.bindCountUpdateForTab(tab);
      });
    };

    SearchResults.prototype.bindCountUpdateForTab = function(tab) {
      return this.subView(tab).collection.on('reset add remove', this.updateCountForTab(tab));
    };

    SearchResults.prototype.unbindCountUpdate = function() {
      var _this = this;
      return _.each(this.getTabs(), function(tab) {
        return _this.unbindCountUpdateForTab(tab);
      });
    };

    SearchResults.prototype.unbindCountUpdateForTab = function(tab) {
      return this.subView(tab).collection.off('reset add remove', this.updateCountForTab(tab));
    };

    SearchResults.prototype.updateCountForTab = function(tab) {
      var _this = this;
      return function(collection) {
        return _this.subView('tabs').updateTabCount(tab, collection.length);
      };
    };

    SearchResults.prototype.showTab = function(tab) {
      var contentSelector;
      contentSelector = _.values(this.tabs).join(', ');
      $(contentSelector).hide();
      return $(this.tabs[tab]).show();
    };

    SearchResults.prototype.teardown = function() {};

    SearchResults.prototype.setResults = function(res) {
      console.log('setting results');
      this.subView('attachments').collection.reset(res.attachments);
      return this.subView('links').collection.reset(res.links);
    };

    return SearchResults;

  })(MeetMikey.View.Base);

}).call(this);
