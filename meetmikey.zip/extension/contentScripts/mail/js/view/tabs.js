(function() {
  var template,
    _this = this,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  template = "<ul class=\"mikey-tabs\">\n  <li class=\"mikey-tab active\" data-mm-tab=\"email\">\n    <a href=\"#\">Email</a>\n  </li>\n  <li class=\"mikey-tab\" data-mm-tab=\"attachments\">\n    <a href=\"#\">\n      Files <span class=\"mm-count\"></span>\n    </a>\n\n  </li>\n  <li class=\"mikey-tab\" data-mm-tab=\"links\">\n    <a href=\"#\">\n      Links <span class=\"mm-count\"></span>\n    </a>\n  </li>\n  <li class=\"mikey-tab\" data-mm-tab=\"images\">\n    <a href=\"#\">\n      Images <span class=\"mm-count\"></span>\n    </a>\n  </li>\n</ul>";

  MeetMikey.View.Tabs = (function(_super) {

    __extends(Tabs, _super);

    function Tabs() {
      var _this = this;
      this.updateTabCount = function(tab, count) {
        return Tabs.prototype.updateTabCount.apply(_this, arguments);
      };
      this.tabClick = function(e) {
        return Tabs.prototype.tabClick.apply(_this, arguments);
      };
      this.getActiveTab = function() {
        return Tabs.prototype.getActiveTab.apply(_this, arguments);
      };
      this.setActiveTab = function(tab) {
        return Tabs.prototype.setActiveTab.apply(_this, arguments);
      };
      this.adjustWidth = function() {
        return Tabs.prototype.adjustWidth.apply(_this, arguments);
      };
      this.postRender = function() {
        return Tabs.prototype.postRender.apply(_this, arguments);
      };
      return Tabs.__super__.constructor.apply(this, arguments);
    }

    Tabs.prototype.template = Handlebars.compile(template);

    Tabs.prototype.events = {
      'click li': 'tabClick'
    };

    Tabs.prototype.postRender = function() {
      return this.adjustWidth();
    };

    Tabs.prototype.adjustWidth = function() {
      var width,
        _this = this;
      width = $('.nH').width();
      this.$el.css('width', width);
      return $(window).resize(function() {
        width = $('.nH').width();
        return _this.$el.css('width', width);
      });
    };

    Tabs.prototype.setActiveTab = function(tab) {
      this.$('.mikey-tab').removeClass('active');
      this.$(".mikey-tab[data-mm-tab='" + tab + "']").addClass('active');
      return MeetMikey.Globals.tabState = tab;
    };

    Tabs.prototype.getActiveTab = function() {
      return this.$('.mikey-tab.active').attr('data-mm-tab');
    };

    Tabs.prototype.tabClick = function(e) {
      var tab, target;
      e.preventDefault();
      target = $(e.currentTarget);
      tab = target.attr('data-mm-tab');
      this.setActiveTab(tab);
      return this.trigger('clicked:tab', tab);
    };

    Tabs.prototype.updateTabCount = function(tab, count) {
      tab = this.$("[data-mm-tab='" + tab + "']");
      return tab.find(".mm-count").text("(" + count + ")");
    };

    return Tabs;

  })(MeetMikey.View.Base);

}).call(this);
