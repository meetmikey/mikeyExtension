(function() {
  var _this = this,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  MeetMikey.View.Search = (function(_super) {

    __extends(Search, _super);

    function Search() {
      var _this = this;
      this.getSearchResults = function(query) {
        return Search.prototype.getSearchResults.apply(_this, arguments);
      };
      this.injectTabBarContainer = function() {
        return Search.prototype.injectTabBarContainer.apply(_this, arguments);
      };
      this.injectSearchResultsContainer = function() {
        return Search.prototype.injectSearchResultsContainer.apply(_this, arguments);
      };
      this.handleSearch = function(query) {
        return Search.prototype.handleSearch.apply(_this, arguments);
      };
      this.postInitialize = function() {
        return Search.prototype.postInitialize.apply(_this, arguments);
      };
      return Search.__super__.constructor.apply(this, arguments);
    }

    Search.prototype.subViews = {
      'searchBar': {
        viewClass: MeetMikey.View.SearchBar,
        selector: '#gbqf'
      },
      'tabs': {
        viewClass: MeetMikey.View.Tabs,
        selector: '#mm-search-tabs-container'
      },
      'searchResults': {
        viewClass: MeetMikey.View.Inbox,
        selector: '#mm-search-container',
        args: {
          fetch: false,
          name: 'searchResult'
        }
      }
    };

    Search.prototype.postInitialize = function() {
      return this.subView('searchBar').on('search', this.handleSearch);
    };

    Search.prototype.handleSearch = function(query) {
      this.subView('searchResults')._teardown();
      this.subView('tabs')._teardown();
      this.injectSearchResultsContainer();
      this.injectTabBarContainer();
      this.subView('tabs').on('clicked:tab', this.subView('searchResults').showTab);
      this.subView('searchResults').on('updateTabCount', this.subView('tabs').updateTabCount);
      this.renderSubview('searchResults');
      this.subView('searchResults').showTab(MeetMikey.Globals.tabState);
      return this.getSearchResults(query);
    };

    Search.prototype.injectSearchResultsContainer = function() {
      var element, selector;
      selector = '.BltHke.nH.oy8Mbf[role=main] .UI';
      element = '<div id="mm-search-container" class="mm-container" style="display: none;"></div>';
      return MeetMikey.Helper.DOMManager.injectBeside(selector, element);
    };

    Search.prototype.injectTabBarContainer = function() {
      var element,
        _this = this;
      element = '<div id="mm-search-tabs-container" class="mm-tabs-container"></div>';
      return MeetMikey.Helper.DOMManager.injectInto('[id=":ro"] [gh="tm"] .nH.aqK', element, function() {
        _this.renderSubview('tabs');
        _this.subView('tabs').setActiveTab(MeetMikey.Globals.tabState);
        return _this.$('.AO').addClass('AO-tabs');
      });
    };

    Search.prototype.getSearchResults = function(query) {
      var _this = this;
      return MeetMikey.Helper.callAPI({
        url: "search",
        type: 'GET',
        data: {
          query: query
        },
        success: function(res) {
          console.log('search successful', res);
          return _this.subView('searchResults').setResults(res, query);
        },
        failure: function() {
          return console.log('search failed');
        }
      });
    };

    return Search;

  })(MeetMikey.View.Base);

}).call(this);
