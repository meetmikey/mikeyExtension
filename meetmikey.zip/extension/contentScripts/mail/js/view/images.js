(function() {
  var template,
    _this = this,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  template = "{{#unless models}}\n \n{{else}}\n  {{#each models}}\n    <div class=\"image-box\" data-cid=\"{{cid}}\">\n      <img class=\"mm-image\" src=\"{{image}}\" />\n      <div class=\"image-text\">\n        {{#if ../searchQuery}}\n          <a href=\"#search/{{../../searchQuery}}/{{msgHex}}\">View email thread</a>\n        {{else}}\n          <a href=\"#inbox/{{msgHex}}\">View email thread</a>\n        {{/if}}\n        <div class=\"rollover-actions\">\n          <!-- <a href=\"#\">Forward</a> -->\n          <a href=\"{{image}}\">Open</a>\n        </div>\n      </div>\n    </div>\n  {{/each}}\n  <div style=\"clear: both;\"></div>\n{{/unless}}";

  MeetMikey.View.Images = (function(_super) {

    __extends(Images, _super);

    function Images() {
      var _this = this;
      this.poll = function() {
        return Images.prototype.poll.apply(_this, arguments);
      };
      this.waitAndPoll = function() {
        return Images.prototype.waitAndPoll.apply(_this, arguments);
      };
      this.setResults = function(models, query) {
        return Images.prototype.setResults.apply(_this, arguments);
      };
      this.initIsotope = function() {
        return Images.prototype.initIsotope.apply(_this, arguments);
      };
      this.checkAndRunIsotope = function() {
        return Images.prototype.checkAndRunIsotope.apply(_this, arguments);
      };
      this.runIsotope = function() {
        return Images.prototype.runIsotope.apply(_this, arguments);
      };
      this.openImage = function(event) {
        return Images.prototype.openImage.apply(_this, arguments);
      };
      this.setCollection = function(attachments) {
        return Images.prototype.setCollection.apply(_this, arguments);
      };
      this.getTemplateData = function() {
        return Images.prototype.getTemplateData.apply(_this, arguments);
      };
      this.postRender = function() {
        return Images.prototype.postRender.apply(_this, arguments);
      };
      this.postInitialize = function() {
        return Images.prototype.postInitialize.apply(_this, arguments);
      };
      return Images.__super__.constructor.apply(this, arguments);
    }

    Images.prototype.template = Handlebars.compile(template);

    Images.prototype.pollDelay = 1000 * 45;

    Images.prototype.events = {
      'click .mm-image': 'openImage'
    };

    Images.prototype.postInitialize = function() {
      this.once('showTab', this.initIsotope);
      this.collection = new MeetMikey.Collection.Images();
      this.collection.on('reset add', _.debounce(this.render, 50));
      if (this.options.fetch) {
        return this.collection.fetch({
          success: this.waitAndPoll
        });
      }
    };

    Images.prototype.postRender = function() {};

    Images.prototype.getTemplateData = function() {
      return {
        models: _.invoke(this.collection.models, 'decorate'),
        searchQuery: this.searchQuery
      };
    };

    Images.prototype.setCollection = function(attachments) {
      var images;
      images = _.filter(attachments.models, function(a) {
        return a.isImage();
      });
      images = _.uniq(images, false, function(i) {
        return "" + (i.get('hash')) + "_" + (i.get('fileSize'));
      });
      return this.collection.reset(images);
    };

    Images.prototype.openImage = function(event) {
      var cid, model, url;
      cid = $(event.currentTarget).closest('.image-box').attr('data-cid');
      model = this.collection.get(cid);
      url = model.get('image');
      return window.open(url);
    };

    Images.prototype.runIsotope = function() {
      console.log('isotoping');
      return this.$el.isotope({
        filter: '*',
        animationOptions: {
          duration: 750,
          easing: 'linear',
          queue: false
        }
      });
    };

    Images.prototype.checkAndRunIsotope = function() {
      console.log('checkAndRunIsotope');
      if (this.areImagesLoaded) {
        console.log('images loaded, clearing interval');
        return clearInterval(this.isotopeInterval);
      } else {
        return this.runIsotope();
      }
    };

    Images.prototype.initIsotope = function() {
      var _this = this;
      console.log('initIsotope');
      this.areImagesLoaded = false;
      this.isotopeInterval = setInterval(this.checkAndRunIsotope, 200);
      return this.$el.imagesLoaded(function() {
        _this.areImagesLoaded = true;
        console.log('images loaded, isotoping one last time');
        return _this.runIsotope();
      });
    };

    Images.prototype.setResults = function(models, query) {
      this.searchQuery = query;
      return this.collection.reset(models, {
        sort: false
      });
    };

    Images.prototype.waitAndPoll = function() {
      return setTimeout(this.poll, this.pollDelay);
    };

    Images.prototype.poll = function() {
      var _ref;
      console.log('images are polling');
      return this.collection.fetch({
        update: true,
        remove: false,
        data: {
          after: (_ref = this.collection.first()) != null ? _ref.get('sentDate') : void 0
        },
        success: this.waitAndPoll,
        error: this.waitAndPoll
      });
    };

    return Images;

  })(MeetMikey.View.Base);

}).call(this);
