(function() {
  var template,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  template = "<div style=\"position: fixed;\" class=\"rollover-box\">\n  <div class=\"rollover-main\">\n    <div class=\"rollover-title\">\n      <a href=\"{{url}}\">{{filename}}</a>\n    </div>\n    <div class=\"rollover-body\">\n      <div class=\"rollover-powerpoint\">\n        {{#if image}}\n\n          <img class=\"powerpoint-preview\" src=\"{{image}}\">\n\n        {{/if}}\n      </div>\n    </div>\n  </div>\n\n  <div class=\"rollover-footer\">\n    {{#if searchQuery}}\n      <a href=\"#search/{{searchQuery}}/{{msgHex}}\">View email thread</a>\n    {{else}}\n      <a href=\"#inbox/{{msgHex}}\">View email thread</a>\n    {{/if}}\n\n    <div class=\"rollover-actions\">\n      <!-- <a href=\"#\">Forward</a> -->\n      <a href=\"{{url}}\">Download</a>\n    </div>\n  </div>\n</div>";

  MeetMikey.View.AttachmentRollover = (function(_super) {

    __extends(AttachmentRollover, _super);

    function AttachmentRollover() {
      return AttachmentRollover.__super__.constructor.apply(this, arguments);
    }

    AttachmentRollover.prototype.template = Handlebars.compile(template);

    return AttachmentRollover;

  })(MeetMikey.View.Rollover);

}).call(this);
