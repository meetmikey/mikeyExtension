(function() {
  var template,
    _this = this,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  template = "{{#unless models}}\n  <div class=\"mm-placeholder\">Oops. It doesn't look like Mikey has any links for you.</div>\n{{else}}\n  <div class=\"pagination-container\"></div>\n  <table class=\"inbox-table\" id=\"mm-links-table\" border=\"0\">\n    <thead class=\"labels\">\n      <th class=\"mm-file mm-link\">Link</th>\n      <th class=\"mm-source\">Source</th>\n      <th class=\"mm-from\">From</th>\n      <th class=\"mm-to\">To</th>\n      <th class=\"mm-sent\">Sent</th>\n    </thead>\n    <tbody>\n      {{#each models}}\n      <tr class=\"files\" data-cid=\"{{cid}}\">\n          <td class=\"mm-file mm-favicon truncate\" style=\"background:url({{faviconURL}}) no-repeat;\">\n            <div class=\"flex\">\n              {{title}}\n              <span class=\"mm-file-text\">{{summary}}</span>\n            </div>\n          </td>\n          <td class=\"mm-source truncate\">{{displayUrl}}</td>\n          <td class=\"mm-from truncate\">{{from}}</td>\n          <td class=\"mm-to truncate\">{{to}}</td>\n          <td class=\"mm-sent truncate\">{{sentDate}}</td>\n        </tr>\n      {{/each}}\n    </tbody>\n  </table>\n  <div class=\"rollover-container\"></div>\n{{/unless}}";

  MeetMikey.View.Links = (function(_super) {

    __extends(Links, _super);

    function Links() {
      var _this = this;
      this.poll = function() {
        return Links.prototype.poll.apply(_this, arguments);
      };
      this.waitAndPoll = function() {
        return Links.prototype.waitAndPoll.apply(_this, arguments);
      };
      this.setResults = function(models, query) {
        return Links.prototype.setResults.apply(_this, arguments);
      };
      this.cancelRollover = function() {
        return Links.prototype.cancelRollover.apply(_this, arguments);
      };
      this.delayRollover = function(event) {
        return Links.prototype.delayRollover.apply(_this, arguments);
      };
      this.startRollover = function(event) {
        return Links.prototype.startRollover.apply(_this, arguments);
      };
      this.openLink = function(event) {
        return Links.prototype.openLink.apply(_this, arguments);
      };
      this.getTemplateData = function() {
        return Links.prototype.getTemplateData.apply(_this, arguments);
      };
      this.teardown = function() {
        return Links.prototype.teardown.apply(_this, arguments);
      };
      this.postRender = function() {
        return Links.prototype.postRender.apply(_this, arguments);
      };
      this.postInitialize = function() {
        return Links.prototype.postInitialize.apply(_this, arguments);
      };
      return Links.__super__.constructor.apply(this, arguments);
    }

    Links.prototype.template = Handlebars.compile(template);

    Links.prototype.subViews = {
      'pagination': {
        viewClass: MeetMikey.View.Pagination,
        selector: '.pagination-container'
      }
    };

    Links.prototype.events = {
      'click .files': 'openLink',
      'mouseenter .files': 'startRollover',
      'mouseleave .files': 'cancelRollover',
      'mousemove .files': 'delayRollover'
    };

    Links.prototype.pollDelay = 1000 * 45;

    Links.prototype.postInitialize = function() {
      this.collection = new MeetMikey.Collection.Links();
      this.rollover = new MeetMikey.View.LinkRollover({
        collection: this.collection,
        search: !this.options.fetch
      });
      this.subView('pagination').collection = this.collection;
      this.collection.on('reset add', _.debounce(this.render, 50));
      this.subView('pagination').on('changed:page', this.render);
      if (this.options.fetch) {
        return this.collection.fetch({
          success: this.waitAndPoll
        });
      }
    };

    Links.prototype.postRender = function() {
      return this.rollover.setElement(this.$('.rollover-container'));
    };

    Links.prototype.teardown = function() {
      return this.collection.off('reset', this.render);
    };

    Links.prototype.getTemplateData = function() {
      return {
        models: _.invoke(this.subView('pagination').getPageItems(), 'decorate')
      };
    };

    Links.prototype.openLink = function(event) {
      var cid, model;
      cid = $(event.currentTarget).attr('data-cid');
      model = this.collection.get(cid);
      return window.open(model.get('url'));
    };

    Links.prototype.startRollover = function(event) {
      return this.rollover.startSpawn(event);
    };

    Links.prototype.delayRollover = function(event) {
      return this.rollover.delaySpawn(event);
    };

    Links.prototype.cancelRollover = function() {
      return this.rollover.cancelSpawn();
    };

    Links.prototype.setResults = function(models, query) {
      this.searchQuery = query;
      this.rollover.setQuery(query);
      return this.collection.reset(models, {
        sort: false
      });
    };

    Links.prototype.waitAndPoll = function() {
      return setTimeout(this.poll, this.pollDelay);
    };

    Links.prototype.poll = function() {
      var _ref;
      console.log('links are polling');
      return this.collection.fetch({
        update: true,
        remove: false,
        data: {
          after: (_ref = this.collection.first()) != null ? _ref.get('sentDate') : void 0
        },
        success: this.waitAndPoll,
        error: this.waitAndPoll
      });
    };

    return Links;

  })(MeetMikey.View.Base);

}).call(this);
