(function() {
  var _this = this,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  MeetMikey.View.Base = (function(_super) {

    __extends(Base, _super);

    function Base() {
      var _this = this;
      this.assign = function(selector, view) {
        return Base.prototype.assign.apply(_this, arguments);
      };
      this.renderSubview = function(name) {
        return Base.prototype.renderSubview.apply(_this, arguments);
      };
      this.renderSubviews = function() {
        return Base.prototype.renderSubviews.apply(_this, arguments);
      };
      this.render = function() {
        return Base.prototype.render.apply(_this, arguments);
      };
      this._teardown = function() {
        return Base.prototype._teardown.apply(_this, arguments);
      };
      this.subView = function(name) {
        return Base.prototype.subView.apply(_this, arguments);
      };
      this.initialize = function() {
        return Base.prototype.initialize.apply(_this, arguments);
      };
      return Base.__super__.constructor.apply(this, arguments);
    }

    Base.prototype.defaultArgs = {
      render: true,
      renderChildren: true
    };

    Base.prototype.initialize = function() {
      var name, obj, _ref, _ref1;
      this.preInitialize();
      this.options = _.defaults((_ref = this.options) != null ? _ref : {}, this.defaultArgs);
      this.subViews = $.extend(true, {}, this.subViews);
      this.options = $.extend(true, {}, this.options);
      _ref1 = this.subViews;
      for (name in _ref1) {
        obj = _ref1[name];
        obj.view = new obj.viewClass(obj.args);
        obj.view.setElement(obj.selector);
      }
      this.postInitialize();
      return this;
    };

    Base.prototype.preInitialize = function() {};

    Base.prototype.postInitialize = function() {};

    Base.prototype.subView = function(name) {
      var _ref;
      return (_ref = this.subViews[name]) != null ? _ref.view : void 0;
    };

    Base.prototype._teardown = function() {
      _.chain(this.subViews).values().pluck('view').invoke('_teardown');
      this.teardown();
      this.trigger('teardown');
      this.off();
      this.remove();
      this.undelegateEvents();
      return this;
    };

    Base.prototype.teardown = function() {};

    Base.prototype.render = function() {
      this.preRender();
      if (this.options.render) {
        this.$el.html(this.template(this.getTemplateData()));
      }
      if (this.options.renderChildren) {
        this.renderSubviews();
      }
      this.postRender();
      return this;
    };

    Base.prototype.preRender = function() {};

    Base.prototype.postRender = function() {};

    Base.prototype.getTemplateData = function() {
      return {};
    };

    Base.prototype.renderSubviews = function() {
      var name;
      for (name in this.subViews) {
        this.renderSubview(name);
      }
      return this;
    };

    Base.prototype.renderSubview = function(name) {
      var view;
      view = this.subViews[name];
      this.assign(view.selector, view.view);
      return this;
    };

    Base.prototype.assign = function(selector, view) {
      return view.setElement(this.$(selector)).render();
    };

    return Base;

  })(Backbone.View);

}).call(this);
