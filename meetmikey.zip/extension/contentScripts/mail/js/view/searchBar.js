(function() {
  var _this = this,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  MeetMikey.View.SearchBar = (function(_super) {

    __extends(SearchBar, _super);

    function SearchBar() {
      var _this = this;
      this.search = function(e) {
        return SearchBar.prototype.search.apply(_this, arguments);
      };
      this.postInitialize = function() {
        return SearchBar.prototype.postInitialize.apply(_this, arguments);
      };
      this.render = function() {
        return SearchBar.prototype.render.apply(_this, arguments);
      };
      return SearchBar.__super__.constructor.apply(this, arguments);
    }

    SearchBar.prototype.render = function() {};

    SearchBar.prototype.postInitialize = function() {
      return $(window).on('hashchange', this.search);
    };

    SearchBar.prototype.search = function(e) {
      var match, query, _ref, _ref1;
      _ref1 = (_ref = window.location.hash.match(/#search\/(.+)/)) != null ? _ref : [], match = _ref1[0], query = _ref1[1];
      if (!((match != null) && (query != null))) {
        return;
      }
      return this.trigger('search', query);
    };

    return SearchBar;

  })(MeetMikey.View.Base);

}).call(this);
