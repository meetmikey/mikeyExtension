(function() {
  var _this = this,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  MeetMikey.View.Main = (function(_super) {

    __extends(Main, _super);

    function Main() {
      var _this = this;
      this.pageNavigated = function() {
        return Main.prototype.pageNavigated.apply(_this, arguments);
      };
      this.showEmailTab = function() {
        return Main.prototype.showEmailTab.apply(_this, arguments);
      };
      this.injectTabBarContainer = function() {
        return Main.prototype.injectTabBarContainer.apply(_this, arguments);
      };
      this.injectInboxContainer = function() {
        return Main.prototype.injectInboxContainer.apply(_this, arguments);
      };
      this.setLayout = function(layout) {
        if (layout == null) {
          layout = 'compact';
        }
        return Main.prototype.setLayout.apply(_this, arguments);
      };
      this.detectLayout = function() {
        return Main.prototype.detectLayout.apply(_this, arguments);
      };
      this.teardown = function() {
        return Main.prototype.teardown.apply(_this, arguments);
      };
      this.postRender = function() {
        return Main.prototype.postRender.apply(_this, arguments);
      };
      this.preRender = function() {
        return Main.prototype.preRender.apply(_this, arguments);
      };
      this.postInitialize = function() {
        return Main.prototype.postInitialize.apply(_this, arguments);
      };
      this.preInitialize = function() {
        return Main.prototype.preInitialize.apply(_this, arguments);
      };
      return Main.__super__.constructor.apply(this, arguments);
    }

    Main.prototype.subViews = {
      'tabs': {
        viewClass: MeetMikey.View.Tabs,
        selector: '#mm-tabs-container'
      },
      'inbox': {
        viewClass: MeetMikey.View.Inbox,
        selector: '#mm-container',
        args: {
          fetch: true,
          name: 'main'
        }
      },
      'search': {
        viewClass: MeetMikey.View.Search,
        selector: '.no .nH.nn',
        args: {
          name: 'search',
          render: false,
          renderChildren: false
        }
      },
      'sidebar': {
        viewClass: MeetMikey.View.Sidebar,
        selector: '.nM[role=navigation]',
        args: {
          render: false
        }
      }
    };

    Main.prototype.preInitialize = function() {
      this.injectInboxContainer();
      this.injectTabBarContainer();
      this.setLayout(this.detectLayout());
      return this.options.render = false;
    };

    Main.prototype.postInitialize = function() {
      this.subView('sidebar').on('clicked:inbox', this.showEmailTab);
      this.subView('tabs').on('clicked:tab', this.subView('inbox').showTab);
      this.subView('inbox').on('updateTabCount', this.subView('tabs').updateTabCount);
      $(window).on('hashchange', this.pageNavigated);
      return MeetMikey.Globals.tabState = 'email';
    };

    Main.prototype.preRender = function() {};

    Main.prototype.postRender = function() {};

    Main.prototype.teardown = function() {
      return this.subViews('sidebar').off('clicked:inbox');
    };

    Main.prototype.detectLayout = function() {
      var padding;
      padding = parseFloat($('.xY').css('padding-top'));
      if (padding < 4.5) {
        return 'compact';
      } else if (8.5 <= padding) {
        return 'comfortable';
      } else {
        return 'cozy';
      }
    };

    Main.prototype.setLayout = function(layout) {
      if (layout == null) {
        layout = 'compact';
      }
      return this.$el.addClass(layout);
    };

    Main.prototype.injectInboxContainer = function() {
      var element;
      element = '<div id="mm-container" class="mm-container" style="display: none;"></div>';
      return MeetMikey.Helper.DOMManager.injectBeside(this.options.inboxTarget, element);
    };

    Main.prototype.injectTabBarContainer = function() {
      var element,
        _this = this;
      element = '<div id="mm-tabs-container" class="mm-tabs-container"></div>';
      return MeetMikey.Helper.DOMManager.injectInto('[id=":ro"] .nH.aqK', element, function() {
        return _this.$('.AO').addClass('AO-tabs');
      });
    };

    Main.prototype.showEmailTab = function() {
      this.subView('tabs').setActiveTab('email');
      return this.subView('inbox').showTab('email');
    };

    Main.prototype.pageNavigated = function() {
      var viewWithTabs;
      viewWithTabs = /#search(?!.+\/)|#inbox(?!\/)/.test(window.location.hash);
      if (viewWithTabs) {
        return this.$('.AO').addClass('AO-tabs');
      } else {
        return this.$('.AO').removeClass('AO-tabs');
      }
    };

    return Main;

  })(MeetMikey.View.Base);

}).call(this);
