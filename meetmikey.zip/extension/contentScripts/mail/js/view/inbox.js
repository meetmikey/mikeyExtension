(function() {
  var template,
    _this = this,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  template = "<div id=\"mm-tabs\"></div>\n<div class=\"mm-attachments-tab\" style=\"display: none;\"></div>\n<div class=\"mm-links-tab\" style=\"display: none;\"></div>\n<div class=\"mm-images-tab\" style=\"display: none;\"></div>";

  MeetMikey.View.Inbox = (function(_super) {

    __extends(Inbox, _super);

    function Inbox() {
      var _this = this;
      this.teardown = function() {
        return Inbox.prototype.teardown.apply(_this, arguments);
      };
      this.setResults = function(res, query) {
        return Inbox.prototype.setResults.apply(_this, arguments);
      };
      this.updateTabCounts = function() {
        return Inbox.prototype.updateTabCounts.apply(_this, arguments);
      };
      this.updateCountForTab = function(tab) {
        return Inbox.prototype.updateCountForTab.apply(_this, arguments);
      };
      this.unbindCountUpdateForTab = function(tab) {
        return Inbox.prototype.unbindCountUpdateForTab.apply(_this, arguments);
      };
      this.unbindCountUpdate = function() {
        return Inbox.prototype.unbindCountUpdate.apply(_this, arguments);
      };
      this.bindCountUpdateForTab = function(tab) {
        return Inbox.prototype.bindCountUpdateForTab.apply(_this, arguments);
      };
      this.bindCountUpdate = function() {
        return Inbox.prototype.bindCountUpdate.apply(_this, arguments);
      };
      this.manageInboxDisplay = function(tab) {
        return Inbox.prototype.manageInboxDisplay.apply(_this, arguments);
      };
      this.hideAllTabs = function() {
        return Inbox.prototype.hideAllTabs.apply(_this, arguments);
      };
      this.showTab = function(tab) {
        return Inbox.prototype.showTab.apply(_this, arguments);
      };
      this.postRender = function() {
        return Inbox.prototype.postRender.apply(_this, arguments);
      };
      this.postInitialize = function() {
        return Inbox.prototype.postInitialize.apply(_this, arguments);
      };
      this.preInitialize = function() {
        return Inbox.prototype.preInitialize.apply(_this, arguments);
      };
      this.getTabs = function() {
        return Inbox.prototype.getTabs.apply(_this, arguments);
      };
      return Inbox.__super__.constructor.apply(this, arguments);
    }

    Inbox.prototype.template = Handlebars.compile(template);

    Inbox.prototype.subViews = {
      'attachments': {
        viewClass: MeetMikey.View.Attachments,
        selector: '.mm-attachments-tab',
        args: {}
      },
      'links': {
        viewClass: MeetMikey.View.Links,
        selector: '.mm-links-tab',
        args: {}
      },
      'images': {
        viewClass: MeetMikey.View.Images,
        selector: '.mm-images-tab',
        args: {}
      }
    };

    Inbox.prototype.tabs = {
      email: '.UI',
      attachments: '.mm-attachments-tab',
      links: '.mm-links-tab',
      images: '.mm-images-tab'
    };

    Inbox.prototype.getTabs = function() {
      return _.chain(this.tabs).keys().without('email').value();
    };

    Inbox.prototype.preInitialize = function() {
      this.subViews.attachments.args.fetch = this.options.fetch;
      this.subViews.links.args.fetch = this.options.fetch;
      this.subViews.attachments.args.name = this.options.name;
      return this.subViews.images.args.fetch = this.options.fetch;
    };

    Inbox.prototype.postInitialize = function() {
      if (!this.options.fetch) {
        return this.bindCountUpdate();
      }
    };

    Inbox.prototype.postRender = function() {};

    Inbox.prototype.showTab = function(tab) {
      var _ref;
      this.hideAllTabs();
      this.manageInboxDisplay(tab);
      $(this.tabs[tab]).show();
      return (_ref = this.subView(tab)) != null ? _ref.trigger('showTab') : void 0;
    };

    Inbox.prototype.hideAllTabs = function() {
      var contentSelector;
      contentSelector = _.values(this.tabs).join(', ');
      return $(contentSelector).hide();
    };

    Inbox.prototype.manageInboxDisplay = function(tab) {
      var method;
      method = tab === 'email' ? 'hide' : 'show';
      return this.$el[method]();
    };

    Inbox.prototype.bindCountUpdate = function() {
      return _.each(this.getTabs(), this.bindCountUpdateForTab);
    };

    Inbox.prototype.bindCountUpdateForTab = function(tab) {
      this.subView(tab).on('reset', this.updateCountForTab(tab));
      return this.subView(tab).collection.on('reset add remove', this.updateCountForTab(tab));
    };

    Inbox.prototype.unbindCountUpdate = function() {
      return _.each(this.getTabs(), this.unbindCountUpdateForTab);
    };

    Inbox.prototype.unbindCountUpdateForTab = function(tab) {
      this.subView(tab).off('reset', this.updateCountForTab(tab));
      return this.subView(tab).collection.off('reset add remove', this.updateCountForTab(tab));
    };

    Inbox.prototype.updateCountForTab = function(tab) {
      var _this = this;
      return function(collection, orCollection) {
        var _ref;
        return _this.trigger('updateTabCount', tab, (_ref = collection.length) != null ? _ref : orCollection.length);
      };
    };

    Inbox.prototype.updateTabCounts = function() {
      var _this = this;
      return _.each(this.getTabs(), function(tab) {
        return _this.updateCountForTab(tab)(_this.subView(tab).collection.length);
      });
    };

    Inbox.prototype.setResults = function(res, query) {
      console.log('setting results');
      this.subView('attachments').setResults(res.attachments, query);
      this.subView('links').setResults(res.links, query);
      return this.subView('images').setResults(res.images, query);
    };

    Inbox.prototype.teardown = function() {
      return this.unbindCountUpdate();
    };

    return Inbox;

  })(MeetMikey.View.Base);

}).call(this);
