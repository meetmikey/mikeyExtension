(function() {
  var template,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  template = "<div style=\"position: fixed;\" class=\"rollover-box\">\n  <div class=\"rollover-main\">\n    <div class=\"rollover-title\">\n      <a href=\"{{url}}\">{{title}}</a>\n    </div>\n    <div class=\"rollover-body\">\n      <div class=\"rollover-image\">\n        {{#if image}}\n\n\n            <div class=\"image-container\">\n                <img class=\"aspectcorrect image-inside\" src=\"{{image}}\">\n            </div>\n\n        {{/if}}\n        {{#if summary}}\n          <div class=\"text-box\">{{summary}}</div>\n        {{/if}}\n      </div>\n    </div>\n  </div>\n\n  <div class=\"rollover-footer\">\n    {{#if searchQuery}}\n      <a href=\"#search/{{searchQuery}}/{{msgHex}}\">View email thread</a>\n    {{else}}\n      <a href=\"#inbox/{{msgHex}}\">View email thread</a>\n    {{/if}}\n    <div class=\"rollover-actions\">\n      <!-- <a href=\"#\">Forward</a> -->\n      <!-- <a href=\"{{url}}\">Download</a> -->\n    </div>\n  </div>\n</div>";

  MeetMikey.View.LinkRollover = (function(_super) {

    __extends(LinkRollover, _super);

    function LinkRollover() {
      return LinkRollover.__super__.constructor.apply(this, arguments);
    }

    LinkRollover.prototype.template = Handlebars.compile(template);

    return LinkRollover;

  })(MeetMikey.View.Rollover);

}).call(this);
