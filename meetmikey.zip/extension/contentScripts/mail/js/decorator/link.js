(function() {
  var LinkDecorator,
    _this = this;

  LinkDecorator = (function() {

    function LinkDecorator() {
      var _this = this;
      this.stripHttp = function(url) {
        return LinkDecorator.prototype.stripHttp.apply(_this, arguments);
      };
      this.formatDate = function(model) {
        return LinkDecorator.prototype.formatDate.apply(_this, arguments);
      };
      this.formatRecipients = function(model) {
        return LinkDecorator.prototype.formatRecipients.apply(_this, arguments);
      };
      this.decorate = function(model) {
        return LinkDecorator.prototype.decorate.apply(_this, arguments);
      };
    }

    LinkDecorator.prototype.httpRegex = /https?:\/\/(.+)/;

    LinkDecorator.prototype.decorate = function(model) {
      var object, _ref, _ref1, _ref2;
      object = {};
      object.title = (_ref = model.get('title')) != null ? _ref : model.get('url');
      object.summary = model.get('summary');
      object.image = model.get('image');
      object.msgHex = model.get('gmMsgHex');
      object.url = model.get('url');
      object.displayUrl = this.stripHttp(model.get('url'));
      object.from = (_ref1 = model.get('sender')) != null ? _ref1.name : void 0;
      object.to = this.formatRecipients(model);
      object.sentDate = this.formatDate(model);
      object.faviconURL = MeetMikey.Helper.getFaviconURL((_ref2 = model.get('resolvedURL')) != null ? _ref2 : model.get('url'));
      object.cid = model.cid;
      return object;
    };

    LinkDecorator.prototype.formatRecipients = function(model) {
      return MeetMikey.Helper.formatRecipients(model.get('recipients'));
    };

    LinkDecorator.prototype.formatDate = function(model) {
      return MeetMikey.Helper.formatDate(model.get('sentDate'));
    };

    LinkDecorator.prototype.stripHttp = function(url) {
      var match;
      match = url.match(this.httpRegex);
      if (match != null) {
        return match[1];
      } else {
        return url;
      }
    };

    return LinkDecorator;

  })();

  MeetMikey.Decorator.Link = new LinkDecorator();

}).call(this);
