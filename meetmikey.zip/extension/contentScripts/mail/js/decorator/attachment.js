(function() {
  var AttachmentDecorator, imgPath,
    _this = this;

  imgPath = MeetMikey.Settings.imgPath;

  AttachmentDecorator = (function() {

    function AttachmentDecorator() {
      var _this = this;
      this.getUrl = function(model) {
        return AttachmentDecorator.prototype.getUrl.apply(_this, arguments);
      };
      this.formatFileSize = function(model, precision) {
        if (precision == null) {
          precision = 1;
        }
        return AttachmentDecorator.prototype.formatFileSize.apply(_this, arguments);
      };
      this.getIconUrlType = function(model) {
        return AttachmentDecorator.prototype.getIconUrlType.apply(_this, arguments);
      };
      this.formatDate = function(model) {
        return AttachmentDecorator.prototype.formatDate.apply(_this, arguments);
      };
      this.formatRecipients = function(model) {
        return AttachmentDecorator.prototype.formatRecipients.apply(_this, arguments);
      };
      this.decorate = function(model) {
        return AttachmentDecorator.prototype.decorate.apply(_this, arguments);
      };
    }

    AttachmentDecorator.prototype.iconUrls = {
      pdf: chrome.extension.getURL("" + imgPath + "/pdf.png"),
      spreadsheet: chrome.extension.getURL("" + imgPath + "/excel.png"),
      document: chrome.extension.getURL("" + imgPath + "/word.png"),
      presentation: chrome.extension.getURL("" + imgPath + "/ppt.png"),
      other: chrome.extension.getURL("" + imgPath + "/unknown.png"),
      code: chrome.extension.getURL("" + imgPath + "/unknown.png"),
      image: chrome.extension.getURL("" + imgPath + "/image.png"),
      music: chrome.extension.getURL("" + imgPath + "/music.png"),
      video: chrome.extension.getURL("" + imgPath + "/video.png"),
      archive: chrome.extension.getURL("" + imgPath + "/zip.png")
    };

    AttachmentDecorator.prototype.decorate = function(model) {
      var object, _ref;
      object = {};
      object.filename = model.get('filename');
      object.from = (_ref = model.get('sender')) != null ? _ref.name : void 0;
      object.to = this.formatRecipients(model);
      object.sentDate = this.formatDate(model);
      object.size = this.formatFileSize(model);
      object.url = this.getUrl(model);
      object._id = model.get('_id');
      object.cid = model.cid;
      object.type = model.get('docType');
      object.iconUrl = this.iconUrls[model.get('docType')];
      object.image = model.get('image');
      object.msgHex = model.get('gmMsgHex');
      return object;
    };

    AttachmentDecorator.prototype.formatRecipients = function(model) {
      return MeetMikey.Helper.formatRecipients(model.get('recipients'));
    };

    AttachmentDecorator.prototype.formatDate = function(model) {
      return MeetMikey.Helper.formatDate(model.get('sentDate'));
    };

    AttachmentDecorator.prototype.getIconUrlType = function(model) {
      var type;
      type = model.get('contentType');
      if (type === "application/pdf") {
        return "pdf";
      } else if (type === "application/zip") {
        return "zip";
      } else if (type === "application/vnd.oasis.opendocument.spreadsheet") {
        return "excel";
      } else if (type === "application/msword" || type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
        return "word";
      } else if (type === "application/vnd.ms-powerpoint" || type === "application/vnd.openxmlformats-officedocument.presentationml.presentation") {
        return "ppt";
      } else if (model.isImage()) {
        return "image";
      } else if (/audio\/.+/.test(type)) {
        return "music";
      } else if (/video\/.+/.test(type)) {
        return "video";
      } else {
        return "unknown";
      }
    };

    AttachmentDecorator.prototype.formatFileSize = function(model, precision) {
      var bytes, convert, gigabyte, kilobyte, megabyte, terabyte;
      if (precision == null) {
        precision = 1;
      }
      bytes = model.get('fileSize');
      convert = function(n, unit) {
        return (n / unit).toFixed(precision);
      };
      kilobyte = 1024;
      megabyte = kilobyte * 1024;
      gigabyte = megabyte * 1024;
      terabyte = gigabyte * 1024;
      if ((0 <= bytes && bytes < kilobyte)) {
        return "" + bytes + " B";
      } else if ((kilobyte <= bytes && bytes < megabyte)) {
        return "" + (convert(bytes, kilobyte)) + " KB";
      } else if ((megabyte <= bytes && bytes < gigabyte)) {
        return "" + (convert(bytes, megabyte)) + " MB";
      } else if ((gigabyte <= bytes && bytes < terabyte)) {
        return "" + (convert(bytes, gigabyte)) + " GB";
      } else if (terabyte <= bytes) {
        return "" + (convert(bytes, terabyte)) + " TB";
      } else {
        return "" + bytes + " B";
      }
    };

    AttachmentDecorator.prototype.getUrl = function(model) {
      var email, refreshToken;
      email = encodeURIComponent(MeetMikey.Helper.OAuth.getUserEmail());
      refreshToken = MeetMikey.globalUser.get('refreshToken');
      return "" + (MeetMikey.Helper.getAPIUrl()) + "/attachmentURL/" + model.id + "?userEmail=" + email + "&refreshToken=" + refreshToken;
    };

    return AttachmentDecorator;

  })();

  MeetMikey.Decorator.Attachment = new AttachmentDecorator();

}).call(this);
