(function() {
  var __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  MeetMikey.Collection.Base = (function(_super) {

    __extends(Base, _super);

    function Base() {
      return Base.__super__.constructor.apply(this, arguments);
    }

    Base.prototype.fetch = function(opts) {
      var apiData;
      opts.cache = false;
      if (MeetMikey.globalUser == null) {
        return Base.__super__.fetch.call(this, opts);
      }
      if (opts == null) {
        opts = {};
      }
      apiData = {
        userEmail: MeetMikey.globalUser.get('email'),
        refreshToken: MeetMikey.globalUser.get('refreshToken')
      };
      if (opts.data != null) {
        _.extend(opts.data, apiData);
      } else {
        opts.data = apiData;
      }
      return Base.__super__.fetch.call(this, opts);
    };

    return Base;

  })(Backbone.Collection);

}).call(this);
