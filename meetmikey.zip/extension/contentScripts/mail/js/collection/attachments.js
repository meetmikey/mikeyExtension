(function() {
  var __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  MeetMikey.Collection.Attachments = (function(_super) {

    __extends(Attachments, _super);

    function Attachments() {
      return Attachments.__super__.constructor.apply(this, arguments);
    }

    Attachments.prototype.url = MeetMikey.Helper.getAPIUrl() + '/attachment';

    Attachments.prototype.model = MeetMikey.Model.Attachment;

    Attachments.prototype.comparator = function(model) {
      return -1 * new Date(model.get('sentDate')).getTime();
    };

    return Attachments;

  })(MeetMikey.Collection.Base);

}).call(this);
